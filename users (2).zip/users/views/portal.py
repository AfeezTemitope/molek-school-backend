"""
MOLEK School - Student Portal Views
Views for student authentication and self-service operations
"""
import logging
from decimal import Decimal
from django.contrib.auth.hashers import check_password, make_password
from django.db.models import Avg, Max, Min, Count
from rest_framework import status
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser

from ..models import (
    ActiveStudent, AcademicSession, Term, CAScore, ExamResult, Subject
)
from ..serializers import (
    StudentLoginSerializer,
    StudentProfileUpdateSerializer,
    AcademicSessionSerializer,
    TermSerializer,
    CAScoreSerializer,
    ExamResultSerializer,
)
from ..cache_utils import (
    make_cache_key,
    get_or_set_cache,
    invalidate_cache,
    get_cached_sessions,
    get_cached_terms,
    CACHE_TIMEOUT_STUDENT,
)

logger = logging.getLogger(__name__)


def get_student_portal_data(student):
    """Helper to format student data for portal"""
    passport_url = None
    if student.passport:
        try:
            passport_url = student.passport.url
        except:
            pass
    
    return {
        'id': student.id,
        'admission_number': student.admission_number,
        'first_name': student.first_name,
        'middle_name': student.middle_name,
        'last_name': student.last_name,
        'full_name': student.full_name,
        'date_of_birth': student.date_of_birth,
        'gender': student.gender,
        'email': student.email,
        'phone_number': student.phone_number,
        'address': student.address,
        'state_of_origin': student.state_of_origin,
        'local_govt_area': student.local_govt_area,
        'class_level_name': student.class_level.name if student.class_level else None,
        'enrollment_session_name': student.enrollment_session.name if student.enrollment_session else None,
        'parent_name': student.parent_name,
        'parent_email': student.parent_email,
        'parent_phone': student.parent_phone,
        'passport_url': passport_url,
        'is_active': student.is_active,
    }


def get_grade(score):
    """Convert score to letter grade"""
    score = float(score) if score else 0
    if score >= 70:
        return 'A'
    elif score >= 60:
        return 'B'
    elif score >= 50:
        return 'C'
    elif score >= 40:
        return 'D'
    return 'F'


def get_remark(score):
    """Get remark based on score"""
    score = float(score) if score else 0
    if score >= 70:
        return 'Excellent'
    elif score >= 60:
        return 'Very Good'
    elif score >= 50:
        return 'Good'
    elif score >= 40:
        return 'Fair'
    return 'Poor'


class StudentLoginView(APIView):
    """Student login using admission number and password."""
    permission_classes = [AllowAny]
    
    def post(self, request):
        serializer = StudentLoginSerializer(data=request.data)
        
        if not serializer.is_valid():
            return Response(
                {'error': 'Invalid credentials format'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        admission_number = serializer.validated_data['admission_number'].upper()
        password = serializer.validated_data['password']
        
        try:
            student = ActiveStudent.objects.select_related(
                'class_level', 'enrollment_session'
            ).get(
                admission_number=admission_number,
                is_active=True
            )
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Invalid admission number or password'},
                status=status.HTTP_401_UNAUTHORIZED
            )
        
        if student.password_plain == password or check_password(password, student.password_hash):
            logger.info(f"Student login successful: {admission_number}")
            return Response({
                'message': 'Login successful',
                'student': get_student_portal_data(student)
            })
        
        return Response(
            {'error': 'Invalid admission number or password'},
            status=status.HTTP_401_UNAUTHORIZED
        )


class StudentProfileView(APIView):
    """Get and update student profile."""
    permission_classes = [AllowAny]
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    
    def get(self, request):
        admission_number = request.query_params.get('admission_number')
        
        if not admission_number:
            return Response(
                {'error': 'Admission number required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.select_related(
                'class_level', 'enrollment_session'
            ).get(admission_number=admission_number.upper())
            return Response(get_student_portal_data(student))
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
    
    def put(self, request):
        return self._update_profile(request)
    
    def patch(self, request):
        return self._update_profile(request)
    
    def _update_profile(self, request):
        admission_number = request.query_params.get('admission_number')
        
        if not admission_number:
            return Response(
                {'error': 'Admission number required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.select_related(
                'class_level', 'enrollment_session'
            ).get(admission_number=admission_number.upper())
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        serializer = StudentProfileUpdateSerializer(
            student, data=request.data, partial=True
        )
        
        if serializer.is_valid():
            serializer.save()
            cache_key = make_cache_key('student_profile', admission_number.upper())
            invalidate_cache(cache_key)
            student.refresh_from_db()
            return Response(get_student_portal_data(student))
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class StudentChangePasswordView(APIView):
    """Change student password."""
    permission_classes = [AllowAny]
    
    def post(self, request):
        admission_number = request.data.get('admission_number')
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')
        
        if not all([admission_number, old_password, new_password]):
            return Response(
                {'error': 'All fields required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.get(
                admission_number=admission_number.upper(),
                is_active=True
            )
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        if not (student.password_plain == old_password or 
                check_password(old_password, student.password_hash)):
            return Response(
                {'error': 'Current password is incorrect'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        student.password_plain = new_password
        student.password_hash = make_password(new_password)
        student.save(update_fields=['password_plain', 'password_hash'])
        
        logger.info(f"Student password changed: {admission_number}")
        return Response({'message': 'Password changed successfully'})


class StudentDashboardStatsView(APIView):
    """Get comprehensive dashboard statistics for a student."""
    permission_classes = [AllowAny]
    
    def get(self, request):
        admission_number = request.query_params.get('admission_number')
        
        if not admission_number:
            return Response(
                {'error': 'Admission number required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.get(
                admission_number=admission_number.upper()
            )
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        results = ExamResult.objects.filter(
            student=student
        ).select_related(
            'subject', 'session', 'term'
        ).order_by('-session__start_date', 'term__name')
        
        total_exams = results.count()
        
        if total_exams == 0:
            return Response({
                'overall': {
                    'averageScore': 0,
                    'totalExams': 0,
                    'passedSubjects': 0,
                    'failedSubjects': 0,
                },
                'sessions': [],
                'recentGrades': [],
                'averageScore': 0,
                'totalExams': 0,
                'passedSubjects': 0,
                'grades': [],
            })
        
        all_scores = [float(r.total_score) for r in results]
        overall_average = round(sum(all_scores) / len(all_scores), 1)
        passed_count = len([s for s in all_scores if s >= 40])
        failed_count = total_exams - passed_count
        
        # Group by session and term
        sessions_data = {}
        
        for result in results:
            session_id = result.session.id
            session_name = result.session.name
            term_id = result.term.id
            term_name = result.term.name
            
            if session_id not in sessions_data:
                sessions_data[session_id] = {
                    'sessionId': session_id,
                    'sessionName': session_name,
                    'isCurrent': result.session.is_current,
                    'terms': {},
                    'allScores': [],
                }
            
            if term_id not in sessions_data[session_id]['terms']:
                sessions_data[session_id]['terms'][term_id] = {
                    'termId': term_id,
                    'termName': term_name,
                    'isCurrent': result.term.is_current,
                    'subjects': [],
                    'scores': [],
                }
            
            score = float(result.total_score)
            sessions_data[session_id]['terms'][term_id]['subjects'].append({
                'subjectName': result.subject.name,
                'caScore': float(result.ca_score),
                'theoryScore': float(result.theory_score),
                'examScore': float(result.exam_score),
                'totalScore': score,
                'grade': result.grade,
                'position': result.position,
                'totalStudents': result.total_students,
            })
            sessions_data[session_id]['terms'][term_id]['scores'].append(score)
            sessions_data[session_id]['allScores'].append(score)
        
        sessions_list = []
        
        for session_id, session_data in sessions_data.items():
            session_scores = session_data['allScores']
            session_average = round(sum(session_scores) / len(session_scores), 1) if session_scores else 0
            session_passed = len([s for s in session_scores if s >= 40])
            
            terms_list = []
            term_order = {'First Term': 1, 'Second Term': 2, 'Third Term': 3}
            
            for term_id, term_data in session_data['terms'].items():
                term_scores = term_data['scores']
                term_average = round(sum(term_scores) / len(term_scores), 1) if term_scores else 0
                term_passed = len([s for s in term_scores if s >= 40])
                
                terms_list.append({
                    'termId': term_data['termId'],
                    'termName': term_data['termName'],
                    'isCurrent': term_data['isCurrent'],
                    'totalSubjects': len(term_scores),
                    'averageScore': term_average,
                    'passedSubjects': term_passed,
                    'failedSubjects': len(term_scores) - term_passed,
                    'grade': get_grade(term_average),
                    'subjects': term_data['subjects'],
                })
            
            terms_list.sort(key=lambda x: term_order.get(x['termName'], 99))
            
            sessions_list.append({
                'sessionId': session_data['sessionId'],
                'sessionName': session_data['sessionName'],
                'isCurrent': session_data['isCurrent'],
                'terms': terms_list,
                'cumulative': {
                    'totalSubjects': len(session_scores),
                    'averageScore': session_average,
                    'passedSubjects': session_passed,
                    'failedSubjects': len(session_scores) - session_passed,
                    'grade': get_grade(session_average),
                }
            })
        
        sessions_list.sort(key=lambda x: x['sessionName'], reverse=True)
        
        recent_results = results[:10]
        recent_grades = [{
            'subjectName': r.subject.name,
            'sessionName': r.session.name,
            'termName': r.term.name,
            'caScore': float(r.ca_score),
            'theoryScore': float(r.theory_score),
            'examScore': float(r.exam_score),
            'totalScore': float(r.total_score),
            'grade': r.grade,
        } for r in recent_results]
        
        return Response({
            'overall': {
                'averageScore': overall_average,
                'totalExams': total_exams,
                'passedSubjects': passed_count,
                'failedSubjects': failed_count,
                'grade': get_grade(overall_average),
            },
            'sessions': sessions_list,
            'recentGrades': recent_grades,
            'averageScore': overall_average,
            'totalExams': total_exams,
            'passedSubjects': passed_count,
            'grades': recent_grades,
        })


class StudentReportCardView(APIView):
    """
    Get MOLEK-style comprehensive report card.
    
    MOLEK Format:
    - Current Term: CA (30) + Exam (70) = 100
    - Note: Exam = Theory + Objective combined
    - Cumulative: 1st Term + 2nd Term + 3rd Term (out of 300)
    """
    permission_classes = [AllowAny]
    
    def get(self, request):
        admission_number = request.query_params.get('admission_number')
        session_id = request.query_params.get('session')
        term_id = request.query_params.get('term')
        
        if not admission_number:
            return Response(
                {'error': 'Admission number required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.select_related(
                'class_level', 'enrollment_session'
            ).get(admission_number=admission_number.upper())
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        # If session/term specified, get specific report
        if session_id and term_id:
            return self._get_term_report(student, session_id, term_id)
        
        # Otherwise return full session report with cumulative
        if session_id:
            return self._get_session_report(student, session_id)
        
        # Return all sessions
        return self._get_all_sessions_report(student)
    
    def _get_term_report(self, student, session_id, term_id):
        """Get single term report"""
        try:
            session = AcademicSession.objects.get(id=session_id)
            term = Term.objects.get(id=term_id)
        except (AcademicSession.DoesNotExist, Term.DoesNotExist):
            return Response(
                {'error': 'Invalid session or term'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        results = ExamResult.objects.filter(
            student=student, session=session, term=term
        ).select_related('subject').order_by('subject__name')
        
        subjects = []
        for r in results:
            # Get class statistics for this subject
            class_results = ExamResult.objects.filter(
                session=session, term=term, subject=r.subject,
                student__class_level=student.class_level
            )
            class_avg = class_results.aggregate(avg=Avg('total_score'))['avg'] or 0
            
            subjects.append({
                'subjectName': r.subject.name,
                'ca1': float(r.ca_score) / 2,  # Split CA into CA1 and CA2 for display
                'ca2': float(r.ca_score) / 2,
                'caTotal': float(r.ca_score),
                'exam': float(r.theory_score) + float(r.exam_score),  # Theory + Exam = 70
                'theoryScore': float(r.theory_score),
                'examScore': float(r.exam_score),
                'total': float(r.total_score),
                'grade': r.grade,
                'position': r.position,
                'totalStudents': r.total_students,
                'classAverage': round(float(class_avg), 1),
                'remark': get_remark(r.total_score),
            })
        
        # Calculate term summary
        total_score = sum(s['total'] for s in subjects)
        avg_score = round(total_score / len(subjects), 1) if subjects else 0
        
        return Response({
            'student': get_student_portal_data(student),
            'session': {
                'id': session.id,
                'name': session.name,
            },
            'term': {
                'id': term.id,
                'name': term.name,
            },
            'subjects': subjects,
            'summary': {
                'totalSubjects': len(subjects),
                'totalScore': total_score,
                'averageScore': avg_score,
                'grade': get_grade(avg_score),
                'passedSubjects': len([s for s in subjects if s['total'] >= 40]),
                'failedSubjects': len([s for s in subjects if s['total'] < 40]),
            }
        })
    
    def _get_session_report(self, student, session_id):
        """Get full session report with cumulative across all terms"""
        try:
            session = AcademicSession.objects.get(id=session_id)
        except AcademicSession.DoesNotExist:
            return Response(
                {'error': 'Invalid session'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        terms = Term.objects.filter(session=session).order_by('name')
        term_order = {'First Term': 1, 'Second Term': 2, 'Third Term': 3}
        terms = sorted(terms, key=lambda t: term_order.get(t.name, 99))
        
        # Get all subjects for this student in this session
        all_results = ExamResult.objects.filter(
            student=student, session=session
        ).select_related('subject', 'term')
        
        # Build subject-wise cumulative data
        subjects_data = {}
        
        for result in all_results:
            subject_name = result.subject.name
            term_name = result.term.name
            
            if subject_name not in subjects_data:
                subjects_data[subject_name] = {
                    'subjectName': subject_name,
                    'firstTerm': None,
                    'secondTerm': None,
                    'thirdTerm': None,
                    'terms': {}
                }
            
            term_data = {
                'ca': float(result.ca_score),
                'exam': float(result.theory_score) + float(result.exam_score),
                'total': float(result.total_score),
                'grade': result.grade,
                'position': result.position,
            }
            
            subjects_data[subject_name]['terms'][term_name] = term_data
            
            if term_name == 'First Term':
                subjects_data[subject_name]['firstTerm'] = term_data['total']
            elif term_name == 'Second Term':
                subjects_data[subject_name]['secondTerm'] = term_data['total']
            elif term_name == 'Third Term':
                subjects_data[subject_name]['thirdTerm'] = term_data['total']
        
        # Calculate cumulative for each subject
        cumulative_subjects = []
        for subject_name, data in subjects_data.items():
            first = data['firstTerm'] or 0
            second = data['secondTerm'] or 0
            third = data['thirdTerm'] or 0
            
            terms_with_scores = sum([1 for t in [first, second, third] if t > 0])
            cumulative_total = first + second + third
            cumulative_avg = round(cumulative_total / terms_with_scores, 1) if terms_with_scores > 0 else 0
            
            # Get class average for cumulative
            class_cumulative = ExamResult.objects.filter(
                session=session, subject__name=subject_name,
                student__class_level=student.class_level
            ).aggregate(avg=Avg('total_score'))['avg'] or 0
            
            cumulative_subjects.append({
                'subjectName': subject_name,
                'firstTerm': first,
                'secondTerm': second,
                'thirdTerm': third,
                'cumulativeTotal': cumulative_total,
                'cumulativePercent': round((cumulative_total / (terms_with_scores * 100)) * 100, 1) if terms_with_scores > 0 else 0,
                'studentAverage': cumulative_avg,
                'classAverage': round(float(class_cumulative), 1),
                'grade': get_grade(cumulative_avg),
                'remark': get_remark(cumulative_avg),
                'terms': data['terms'],
            })
        
        # Sort subjects alphabetically
        cumulative_subjects.sort(key=lambda x: x['subjectName'])
        
        # Overall cumulative
        all_cumulative_totals = [s['cumulativeTotal'] for s in cumulative_subjects]
        all_student_avgs = [s['studentAverage'] for s in cumulative_subjects if s['studentAverage'] > 0]
        
        overall_cumulative = sum(all_cumulative_totals)
        overall_avg = round(sum(all_student_avgs) / len(all_student_avgs), 1) if all_student_avgs else 0
        
        return Response({
            'student': get_student_portal_data(student),
            'session': {
                'id': session.id,
                'name': session.name,
            },
            'terms': [{'id': t.id, 'name': t.name} for t in terms],
            'subjects': cumulative_subjects,
            'cumulative': {
                'totalSubjects': len(cumulative_subjects),
                'totalScore': overall_cumulative,
                'averageScore': overall_avg,
                'grade': get_grade(overall_avg),
                'passedSubjects': len([s for s in cumulative_subjects if s['studentAverage'] >= 40]),
                'failedSubjects': len([s for s in cumulative_subjects if s['studentAverage'] < 40]),
            }
        })
    
    def _get_all_sessions_report(self, student):
        """Get report for all sessions"""
        sessions = AcademicSession.objects.filter(
            exam_results__student=student
        ).distinct().order_by('-start_date')
        
        sessions_data = []
        for session in sessions:
            report = self._get_session_report(student, session.id)
            if report.status_code == 200:
                sessions_data.append(report.data)
        
        return Response({
            'student': get_student_portal_data(student),
            'sessions': sessions_data,
        })


class StudentGradesView(APIView):
    """Get all grades for a student."""
    permission_classes = [AllowAny]
    
    def get(self, request):
        admission_number = request.query_params.get('admission_number')
        
        if not admission_number:
            return Response(
                {'error': 'Admission number required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.get(
                admission_number=admission_number.upper()
            )
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        results = ExamResult.objects.filter(
            student=student
        ).select_related(
            'subject', 'session', 'term'
        ).order_by('-session__start_date', 'term__name')
        
        grades = []
        for r in results:
            grades.append({
                'id': r.id,
                'subject_name': r.subject.name,
                'session': r.session.id,
                'session_name': r.session.name,
                'term': r.term.id,
                'term_name': r.term.name,
                'ca_score': float(r.ca_score),
                'theory_score': float(r.theory_score),
                'exam_score': float(r.exam_score),
                'total_score': float(r.total_score),
                'grade': r.grade,
                'position': r.position,
                'total_students': r.total_students,
                'class_average': float(r.class_average) if r.class_average else None,
            })
        
        return Response({'grades': grades})


class StudentCAScoresView(APIView):
    """Get CA scores for a student."""
    permission_classes = [AllowAny]
    
    def get(self, request):
        admission_number = request.query_params.get('admission_number')
        session_id = request.query_params.get('session')
        term_id = request.query_params.get('term')
        
        if not admission_number:
            return Response(
                {'error': 'Admission number required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.get(
                admission_number=admission_number.upper()
            )
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        ca_scores = CAScore.objects.filter(student=student)
        
        if session_id:
            ca_scores = ca_scores.filter(session_id=session_id)
        if term_id:
            ca_scores = ca_scores.filter(term_id=term_id)
        
        ca_scores = ca_scores.select_related(
            'subject', 'session', 'term'
        ).order_by('-session__start_date')
        
        return Response({
            'ca_scores': CAScoreSerializer(ca_scores, many=True).data
        })


class StudentExamResultsView(APIView):
    """Get exam results for a student."""
    permission_classes = [AllowAny]
    
    def get(self, request):
        admission_number = request.query_params.get('admission_number')
        session_id = request.query_params.get('session')
        term_id = request.query_params.get('term')
        
        if not admission_number:
            return Response(
                {'error': 'Admission number required'},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        try:
            student = ActiveStudent.objects.get(
                admission_number=admission_number.upper()
            )
        except ActiveStudent.DoesNotExist:
            return Response(
                {'error': 'Student not found'},
                status=status.HTTP_404_NOT_FOUND
            )
        
        results = ExamResult.objects.filter(student=student)
        
        if session_id:
            results = results.filter(session_id=session_id)
        if term_id:
            results = results.filter(term_id=term_id)
        
        results = results.select_related(
            'subject', 'session', 'term'
        ).order_by('-session__start_date')
        
        return Response({
            'exam_results': ExamResultSerializer(results, many=True).data
        })


class StudentSessionsView(APIView):
    """Get all academic sessions"""
    permission_classes = [AllowAny]
    
    def get(self, request):
        sessions = get_cached_sessions()
        return Response({
            'sessions': AcademicSessionSerializer(sessions, many=True).data
        })


class StudentTermsView(APIView):
    """Get all terms"""
    permission_classes = [AllowAny]
    
    def get(self, request):
        session_id = request.query_params.get('session')
        terms = get_cached_terms(session_id)
        return Response({
            'terms': TermSerializer(terms, many=True).data
        })
from django.contrib.auth import get_user_model
from django.db.models.signals import post_migrate
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Student
import logging
from decouple import config

logger = logging.getLogger(__name__)

@receiver(post_save, sender=Student)
def send_student_credentials_to_parent(sender, instance, created, **kwargs):
    if created:

        # ✅ NEW WAY: Access via _raw_password (private attr)
        raw_password = getattr(instance, '_raw_password', None)

        if not raw_password:
            logger.error("No raw password found for student. This should not happen!")
            return

        message = (
            f"Dear Parent,\n\n"
            f"Your child {instance.first_name} {instance.last_name} has been enrolled.\n"
            f"Admission No: {instance.admission_number}\n"
            f"Password: {raw_password}\n"
            f"Login: https://student.molekschools.edu.ng\n\n"
            f"Please change the password after first login.\n\n"
            f"Best regards,\n"
            f"Molek Schools"
        )

        logger.info(f"[SMS MOCK] To: {instance.parent_phone}\n{message}")
        print(f"[SMS MOCK] To: {instance.parent_phone}\n{message}")

        # Clear temp password after use
        instance._raw_password = None
@receiver(post_migrate)
def create_superuser(sender, **kwargs):
    if sender.name != "django.contrib.auth":
        return
    if config("DJANGO_ENV") != "prod":
        logger.info("Skipping superuser creation (not production).")
        return
    User = get_user_model()
    username = config("DJANGO_SUPERUSER_USERNAME")
    email = config("DJANGO_SUPERUSER_EMAIL")
    password = config("DJANGO_SUPERUSER_PASSWORD")

    if username and email and password:
        if not User.objects.filter(username=username).exists():
            User.objects.create_superuser(
                username=username,
                email=email,
                password=password,
                first_name="molek",
                last_name="school"
            )

            logger.info(f"✅ Superuser '{username}' created successfully.")
        else:
            logger.info(f"ℹ️ Superuser '{username}' already exists.")
    else:
        logger.warning("⚠️ Superuser env vars not set, skipping creation.")